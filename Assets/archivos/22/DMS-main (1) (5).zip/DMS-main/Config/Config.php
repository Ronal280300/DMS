<?php
const BASE_URL = "http://localhost/DMS/DMS/";
const HOST = "localhost";
const USER = "root";
const PASS = "";
const DB = "gestion_archivos";
const CHARSET = "charset=utf8";
?>