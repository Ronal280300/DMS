<?php
const BASE_URL = "http://localhost/DMS/";
const HOST = "localhost";
const USER = "root";
const PASS = "";
const DB = "gestion_archivos";
const CHARSET = "charset=utf8";
// configuracion para resetar contraseña
// si no configuras no funcionará el envio de correo
const HOST_SMTP = "smtp.gmail.com";
const USER_SMTP = 'prueba@gmail.com';
const CLAVE_SMTP = '32323123223';
const PUERTO_SMTP = 465;
const CORREO_FROM = 'angelsifuentes2580@gmail.com';
const TITLE = 'Vida informatico';
?>